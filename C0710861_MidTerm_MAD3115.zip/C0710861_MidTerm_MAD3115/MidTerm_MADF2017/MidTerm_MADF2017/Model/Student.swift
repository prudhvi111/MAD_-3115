//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import Foundation
class Student {
    var studentid : String?
    var studentName: String?
    var studentmailid: String
    var  studentbirthdate:  String?
    var subject1:  String?
    var subject2:  String?
    var subject3:  String?
    var subject4:  String?
    var subject5:  String?
    


}
