//
//  ViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import UIKit

class LoginViewController : UIViewController {

    @IBOutlet weak var emailid: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

 
    @IBAction func loginclick(_ sender: UIButton) {
    
        
        if(emailid.text == "prudhvivegesna@gmail.com" && password.text == "sairam")
        {
            print("Hello, My First Click : ", emailid.text! )
        }
        else{
            print("emailid / password incorrect")
        }
    }
}


