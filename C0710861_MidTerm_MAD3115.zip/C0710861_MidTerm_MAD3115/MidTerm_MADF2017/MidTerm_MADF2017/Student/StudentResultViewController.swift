//
//  StudentResultViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0710861
//  Student Name : PRUDHVI RAJU VEGESNA

import UIKit

class StudentResultViewController: UIViewController {

    @IBOutlet weak var studentid: UITextField!
    
    
    @IBOutlet weak var studentname: UITextField!
    
    
    @IBOutlet weak var studentmailid: UITextField!
    
    
    @IBOutlet weak var studentbirthday: UITextField!
    
    
    @IBOutlet weak var subject1: UITextField!
    
    
    @IBOutlet weak var subject2: UITextField!
    
    @IBOutlet weak var subject3: UITextField!
    
    
    @IBOutlet weak var subject4: UITextField!
    
    
    @IBOutlet weak var subject5: UITextField!
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
